//태양, 달이 될 수 있는 위치 고정(전역변수)
let x_sun = 250; 
let y_sun = 100;


function setup() {
  createCanvas(500, 500);
  background(220);
}

function draw() {
  let r = mouseX % 9;
  let x1 = mouseX; //(mouseX의 위치) - 지역변수
  let y1 = mouseY; // mouseY의 위치 - 지역변수
  let color_day = color(80, 188, 233); // 낮일때 배경색 (지역변수)
  let color_sunset = color(242, 152, 134); // 노을진 시간 일때 배경색 (지역변수)
  let color_night = color(2, 7, 21) // 밤일때 배경색(지역변수)
  BG(x1, y1, color_day, color_sunset, color_night);
  wind(r, x1);
  building();
  sky(x1, y1);
  mouseClicked(x1, y1);
  
  
  /* 콘솔 출력
  mouseX 위치와 
  시간 (DAY, SUNSET, NIGHT) 표시
  */
  if (x1 < (500 / 3)) 
  {
    console.log('mouse X : ' + mouseX, 'time is day');
  }

  else if (500/ 3 < x1 && x1 < 1000 / 3)
  {
    console.log('mouse X : ' + mouseX, 'time is SUNSET');

  }
  else
  {
    console.log('mouse X : ' + mouseX, 'time is NIGHT');
  }
  
}

function BG(x, y, day, sunset, night) 
// BackGround 배경 색 지정함수
{
  if (x < (500 / 3)) // 한낮일때의 배경
  {
    background(day);
  }
  //노을일때의 배경
  else if (500/ 3 < x && x < 1000 / 3)
  {
    background(sunset);

  }
  else // 밤일때 배경
    {
      background(night);
    }
}

function wind(r, x)
{
  strokeWeight(3);
  if (x < (500 / 3)) // 한낮일때
  {
    stroke(0, 0, 0);
    
  }
  //노을일때
  else if (500/ 3 < x && x < 1000 / 3)
  {
    stroke(243, 97, 220);
  }
  else // 밤일때
  {
      stroke(255, 255, 255);
  }

  if (0 <= r && r < 3) {
    line(130, 220, 100, 200);
    line(430, 50, 460, 70);
    line(70, 30, 100, 50);
    line(400, 200, 430, 220);
    line(190, 270, 220, 290);
    line(300, 220, 330, 240);
    line(70, 420, 100, 440);
    
  }  
  else if (3 <= r && r < 6){
    line(350, 450, 380, 470);
    line(350, 250, 380, 270);
    line(250, 50, 280, 70);
    line(50, 450, 80, 470);
  }  
}

function building() // Building
{
  noStroke();
  //왼쪽부터 building
  fill(103, 153, 255);
  quad(0, 0, 100, 20, 150, 80, 0, 500);
  fill(67, 116, 217); // 맨 왼쪽빌딩 입체감 표현
  quad(0, 500, 150, 80, 150, 100, 30, 500);
  
  //중앙의 흰색 building
  fill(255, 255, 255);
  quad(250, 500, 250, 200, 300, 120, 350, 500);
  
  fill(234, 234, 234);
  quad(300, 120, 350, 500, 420, 500, 330, 140);
  
  fill(178, 204, 255);
  quad(430, 500, 340, 140, 370, 100, 500, 350)
  triangle(430, 500, 500, 350, 500, 500);
  fill(0, 51, 153);
  quad(370, 100, 390, 100, 500, 280, 500, 350);
  
  fill(67, 116, 217);
  quad(250, 500, 250, 400, 200, 390, 200, 500);
  fill(103, 153, 255);
  quad(200, 390, 200, 500, 130, 500, 130, 480);
  
  // 빌딩의 유리창부분
  fill(61, 183, 255);
  quad(0, 480, 0, 10, 90, 30, 135, 85) // 맨왼쪽
  stroke(0);
  strokeWeight(5);
  line(0, 350, 26, 400);
  strokeWeight(4);
  line(0, 220, 58, 310);
  strokeWeight(3);
  line(0, 90, 93, 210);
  strokeWeight(2);
  line(0, 10, 115, 140);
  strokeWeight(1);
  line(50, 21, 126, 108);
  
  
  noStroke();
  fill(178, 204, 255);
  quad(255, 500, 255, 200, 295, 135, 335, 500); // 중앙 오른쪽
  fill(217, 229, 255);
  quad(440, 500, 346, 140, 370, 110, 500, 365);
  triangle(500, 365, 500, 500, 440, 500);
}

function sky(x, y)
{
  noStroke();
  if (x < (500 / 3)) // 한낮
  {
    fill(255, 255, 255);
  }
  else if (500/ 3 < x && x < 1000 / 3)
  {//노을
    fill(250, 237, 125);
  }
  else
    {// 밤
      fill(255, 255, 255);
    }
  ellipse(x_sun, y_sun, 16, 16);
  
}

function mouseClicked(x, y)
{
  stroke(255,255,255);
  strokeWeight(6);
  point(x, y);
}

