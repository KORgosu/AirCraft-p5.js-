function setup() {
  createCanvas(400, 400);
  strokeWeight(2);
  background(2, 7, 21);
}

function draw() {
  t();
  let dx = 10; 
  let dc = 30;
  let squareDraw = 10;
  if (mouseIsPressed === true) {
    for (let i = squareDraw; i > 0; i--)     {
      let c = (i * dc) % 256; // 0 ~ 255
      fill(c);
      rect(mouseX, mouseY, i * dx, i * dx);
    } 
  }
  
}

function t(){
  strokeWeight(3);
  stroke(255, 215, 0);
  fill(2, 7, 21);
  ellipse(200, 200, 300);
  ellipse(200, 200, 230);
  ellipse(200, 200, 160);
  strokeWeight(6);
  ellipse(200, 200, 145);
  strokeWeight(2);
  ellipse(200, 200, 130);
  
  fill(255,215,0);
  ellipse(200, 200, 100);
  fill(2, 7, 21);
  noStroke();
  ellipse(212, 200, 80);
  
  strokeWeight(3);
  stroke(255, 215, 0);
  line(200, 51, 160, 130);
  line(200, 51, 240, 130);
  line(50, 200, 130, 160);
  line(50, 200, 130, 240);
  line(350, 200, 270, 160);
  line(350, 200, 270, 240);
  line(200, 350, 160, 270);
  line(200, 350, 240, 270);

}