let count = 10;

function setup() {
  createCanvas(630, 630);
  noLoop();
}

function draw() {
  background(0);
  
  for (let i = 90; i < 560; i += 90)
    {
      for (let j = 110, k = 1; j < 560; j += 110, k += 1)
        {
          let a = k * 240;
          drawPattern(i, j, a);
        }
    }
}

function drawPattern(x, y, a){

  let dx = 5 + 5 * random();
  let dc_1 = 70 * random();
  let dc_2 = 50 * random();
  let dc_3 = 30 * random();
  let ab = 4;
  push();
  translate(x, y);
  
  noStroke();
  a = a % 360;
  for (let i = 0; i < count; i++)
    {
      rotate(a);

      fill(255 - dc_1, 255 - dc_2, 255 - dc_3);
      rect(0, 0, ab * dx, ab * dx);
    }
  
  pop();
}