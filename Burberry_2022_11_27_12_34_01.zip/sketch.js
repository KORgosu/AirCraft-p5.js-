let pSize = [180, 180];
let mX, mY;
let newColor = [];

function setup() {
  createCanvas(540, 540);
  mX = (int) (width/180);
  mY = (int) (height/180);
  
  for (let i = 0; i < 3; i++)
  {
    newColor[i] = [];
  }
}

function draw() {
  background(220);
  assignColor(newColor, mX, mY);
  drawRect(newColor, mX, mY);
  drawStripe();
}

function assignColor(newColor, mX, mY)
{
  for (let i = 0; i < mX; i++)
    for (let j = 0; j < mY; j++)
      if (i == 0 || i == 2)
        if (j == 0 || j == 2)
          newColor[i][j] = color(236, 218, 182);
        else
          newColor[i][j] = color(255, 255, 255);
      else
        newColor[i][j] = color(255, 255, 255);
}

function drawRect(newColor, mX, mY)
{
  noStroke();
  for (let i = 0; i < mX; i++)
    {
      for (let j = 0; j < mY; j++){
        fill(newColor[i][j]);
        rect(i * pSize[0], j * pSize[1], pSize[0], pSize[1]);
      }
    }
}

function drawStripe()
{
  fill(241,88,88);
  rect(0, 50, 540, 30);
  rect(0, 460, 540, 30);
  rect(50, 0, 30, 540);
  rect(460, 0, 30, 540);
  
  for (let i = 0; i < 2; i++){
    for (let j = 0 ; j < 2; j++){
      fill(172,25,25)
      rect(50 + i * 410, 50 + j * 410, 30, 30);
    }
  }
  
  for (let i = 0; i < 3; i++){
    fill(100, 100, 100);
    rect(0, 180 + 72 * i, 540, 36);
    rect(180 + 72 * i, 0, 36, 540);
  }
  
  for (let i = 0; i < 3; i++){
    for (let j = 0; j < 3; j++){
      fill(2, 7, 21);
      rect(180 + i * 72, 180 + j * 72, 36, 36);
    }
  }
  
  fill(90,10,10);
  rect(180, 50, 36, 30);
  rect(252, 50, 36, 30);
  rect(324, 50, 36, 30);
  rect(180, 460, 36, 30);
  rect(252, 460, 36, 30);
  rect(324, 460, 36, 30);
  rect(50, 180, 30, 36);
  rect(50, 252, 30, 36);
  rect(50, 324, 30, 36);
  rect(460, 180, 30, 36);
  rect(460, 252, 30, 36);
  rect(460, 324, 30, 36);
}




