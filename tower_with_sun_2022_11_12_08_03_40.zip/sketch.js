let backGround = 100;
let dragColor;
let moveColor;
function setup() {
  createCanvas(400, 400);
  dragColor = color(150, 150, 0);
}

function draw() {
  background(backGround);
  let bigCc = dragColor;
  let bigCc2 = moveColor;
  
  noStroke();
  fill(bigCc);
  ellipse(100, 100, 150);
  
  tower();
}
  

function mouseClicked() // 마우스를 클릭할때마다 배경색 바꾸기
{
  backGround += 20;
  if (backGround == 240)
    {
      backGround = 100;
    }
}

function mouseDragged() // Drag 할때마다 태양의 색이 변함
{
  let r = map(mouseX, 0, width, 250, 350);
  let g = map(mouseX, 0, width, 200, 300);
  let b = map(mouseX, 0, width, 50, 150);
  
  if (r > 350)
    r = 250;
  if (g > 300)
    g = 200;
  if (b > 150)
    b = 150;
  dragColor = color(r, g, b);
}

function mouseMoved() {
    moveColor = mouseX%255;
}

function tower() // tower 속 불빛을 mouseMoved에 의해 제어
{
  fill(200, 194, 182);
  quad(275, 400, 355, 400, 355, 200, 275, 200);
  quad(260, 200, 370, 200, 370, 100, 260, 100);
  
  
  fill(moveColor, moveColor, moveColor);
  quad(280, 400, 290, 400, 290, 200, 280, 200);
  quad(300, 400, 310, 400, 310, 200, 300, 200);
  quad(320, 400, 330, 400, 330, 200, 320, 200);
  quad(340, 400, 350, 400, 350, 200, 340, 200);
  
  stroke(100);
  strokeWeight(1);
  fill(200, 194, 182);
  quad(270, 220, 270, 240, 360, 240, 360, 220);
  quad(270, 270, 270, 290, 360, 290, 360, 270);
  quad(270, 320, 270, 340, 360, 340, 360, 320);
  
  strokeWeight(4);
  stroke(150, 75, 0);
  quad(270, 190, 360, 190, 360, 110, 270, 110);
  fill(255, 255, 255);
  ellipse(315, 150, 90);
  
  fill(0, 103, 163);
  strokeWeight(8);
  point(315, 150);
  strokeWeight(3);
  line(315, 150, 285, 150);
  line(315, 150, 315, 115);
  
  noStroke();
  quad(275, 100, 355, 100, 355, 70, 275, 70);
  
  fill(moveColor, moveColor, moveColor);
  quad(280, 100, 290, 100, 290, 70, 280, 70);
  quad(300, 100, 310, 100, 310, 70, 300, 70);
  quad(320, 100, 330, 100, 330, 70, 320, 70);
  quad(340, 100, 350, 100, 350, 70, 340, 70);
  
  noStroke();
  
  fill(0, 103, 163);
  quad(275, 70, 355, 70, 335, 50, 295, 50);
  fill(200, 194, 182);
  quad(335, 50, 295, 50, 295, 30, 335, 30);
  fill(0, 103, 163);
  triangle(295, 30, 335, 30, 315, 5);
  
  
  
}